export const arrayHeader = [
  { text: 'Inicio', href: '#inicio' },
  { text: 'Crear', href: '#crear' },
  { text: 'Explorar', href: '#explorar' }
]

export const arrayUser = [
  { img: '../Header/Header_img/campana.png', href: '#notif' },
  { img: '../Header/Header_img/comments.png', href: '#messeges' },
  { img: '../Header/Header_img/frame.png', href: '#user' }
]
