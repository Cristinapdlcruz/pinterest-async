import './style.css'
import { header } from './src/componentes/Header/Header'
import { printGallery } from './src/componentes/Gallery/Gallery'

header()
printGallery()
